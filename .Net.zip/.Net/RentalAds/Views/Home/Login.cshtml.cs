using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RentalAds.Views.Home
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
