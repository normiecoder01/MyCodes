﻿namespace RentalAds.Models
{
    public class LoginViewModel
    {
        public string UserType { get; set; }
        public string Password { get; set; }
        public string Contact { get; set; }
    }
}
